export const products = [
  { 
    id: 1, 
    name: 'Ethiopian Coffee', 
    price: 18.99, 
    stock: 50, 
    image: 'https://images.unsplash.com/photo-1524350876685-274059332603?w=400' 
  },
  { 
    id: 2, 
    name: 'Colombian Coffee', 
    price: 16.99, 
    stock: 75, 
    image: 'https://images.unsplash.com/photo-1551610290-e153ec567dd8?w=400' 
  },
  { 
    id: 3, 
    name: 'Italian Espresso', 
    price: 19.99, 
    stock: 30, 
    image: 'https://images.unsplash.com/photo-1618105965240-9aa565e73a0a?w=400' 
  },
  { 
    id: 4, 
    name: 'Brazilian Coffee', 
    price: 15.99, 
    stock: 60, 
    image: 'https://images.unsplash.com/photo-1612487458970-564127ec86f5?w=400' 
  },
];